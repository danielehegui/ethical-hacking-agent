# AgentEthical: Agente de Ethical Hacking OWASP LLM Top 10

Este proyecto implementa un agente automatizado para pruebas de ethical hacking y validación de controles de seguridad en aplicaciones que utilizan modelos de lenguaje (LLM), siguiendo el estándar OWASP LLM Top 10 y OWASP ZAP Top 10.

## Funcionalidades principales

- **Ejecución automática de escenarios de seguridad**: El agente recorre archivos `.feature` con escenarios de prueba para los riesgos OWASP LLM Top 10 y ZAP Top 10.
- **Soporte para canales Web y WhatsApp**: Envía mensajes de prueba a endpoints de chatbot por ambos canales, simulando ataques y consultas legítimas.
- **Análisis de respuestas**: Evalúa si la respuesta del sistema es segura, funcional y no expone información sensible.
- **Generación de reporte detallado**: Crea `reporte_pruebas_detallado.csv` con los resultados de cada escenario, incluyendo análisis de seguridad y cumplimiento esperado.
- **Fácil extensión**: Puedes agregar nuevos escenarios editando los archivos `.feature` en `features/owasp_llm_top10/`.

## Estructura del proyecto

- `features/owasp_llm_top10/` y `features/owasp_zap_top10/`: Escenarios de prueba en formato Gherkin.
- `featuresEH/ethical_hacking_agent.py`: Script principal del agente.
- `reporte_pruebas_detallado.csv`: Reporte generado tras la ejecución.

## Uso

1. Instala dependencias (si es necesario):
   ```sh
   pip install requests
   ```
2. Ejecuta el agente:
   ```sh
   python3 featuresEH/ethical_hacking_agent.py
   ```
3. Revisa el reporte generado en `reporte_pruebas_detallado.csv`.

## Personalización

- Para agregar o modificar escenarios, edita los archivos `.feature`.
- Puedes ampliar los análisis de seguridad modificando la función `analizar_respuesta` en el script del agente.

## Seguridad
- El agente está diseñado para identificar riesgos como prompt injection, fuga de datos, manejo inseguro de errores, exposición de información sensible, y más.
- Los resultados ayudan a fortalecer los controles de seguridad en aplicaciones que usan LLM.

## Autor
- danielehegui_bcp

---

¡Contribuciones y mejoras son bienvenidas!
